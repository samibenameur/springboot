package com.etraining.etraining;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtrainingApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtrainingApplication.class, args);
	}
}

