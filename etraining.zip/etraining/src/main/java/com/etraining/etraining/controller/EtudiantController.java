package com.etraining.etraining.controller;



import com.etraining.etraining.entity.Etudiant;
import com.etraining.etraining.service.EtudiantService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/etudiants")
public class EtudiantController {

    private final EtudiantService etudiantService;

    public EtudiantController(EtudiantService etudiantService) {
        this.etudiantService = etudiantService;
    }

    // Liste des étudiants
    @GetMapping
    public String listEtudiants(Model model) {
        model.addAttribute("etudiants", etudiantService.findAll());
        return "etudiants/list"; // Thymeleaf template à créer
    }

    // Formulaire création
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("etudiant", new Etudiant());
        return "etudiants/form";
    }

    // Enregistrer nouvel étudiant
    @PostMapping
    public String saveEtudiant(@ModelAttribute("etudiant") Etudiant etudiant) {
        etudiantService.save(etudiant);
        return "redirect:/etudiants";
    }

    // Formulaire modification
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Etudiant etudiant = etudiantService.findById(id).orElseThrow(() -> new IllegalArgumentException("Id étudiant invalide : " + id));
        model.addAttribute("etudiant", etudiant);
        return "etudiants/form";
    }

    // Suppression étudiant
    @GetMapping("/delete/{id}")
    public String deleteEtudiant(@PathVariable("id") Long id) {
        etudiantService.deleteById(id);
        return "redirect:/etudiants";
    }
}
