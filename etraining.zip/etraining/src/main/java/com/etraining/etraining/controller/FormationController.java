package com.etraining.etraining.controller;

import com.etraining.etraining.entity.Formation;
import com.etraining.etraining.service.FormationService;
import com.etraining.etraining.service.FormateurService;
import com.etraining.etraining.service.SalleService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/formations")
public class FormationController {

    private final FormationService formationService;
    private final FormateurService formateurService;
    private final SalleService salleService;

    public FormationController(FormationService formationService, FormateurService formateurService, SalleService salleService) {
        this.formationService = formationService;
        this.formateurService = formateurService;
        this.salleService = salleService;
    }

    @GetMapping
    public String listFormations(Model model) {
        model.addAttribute("formations", formationService.getAllFormations());
        return "formations/list";
    }

    @GetMapping("/new")
    public String showForm(Model model) {
        model.addAttribute("formation", new Formation());
        model.addAttribute("formateurs", formateurService.getAllFormateurs());
        model.addAttribute("salles", salleService.getAllSalles());
        return "formations/form";
    }

    @PostMapping
    public String saveFormation(@ModelAttribute Formation formation) {
        formationService.saveFormation(formation);
        return "redirect:/formations";
    }

    @GetMapping("/edit/{id}")
    public String editFormation(@PathVariable Long id, Model model) {
        Formation formation = formationService.getFormationById(id).orElseThrow();
        model.addAttribute("formation", formation);
        model.addAttribute("formateurs", formateurService.getAllFormateurs());
        model.addAttribute("salles", salleService.getAllSalles());
        return "formations/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteFormation(@PathVariable Long id) {
        formationService.deleteFormation(id);
        return "redirect:/formations";
    }
}
