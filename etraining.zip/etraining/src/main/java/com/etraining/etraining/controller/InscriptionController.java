package com.etraining.etraining.controller;

import com.etraining.etraining.entity.*;
import com.etraining.etraining.service.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@Controller
@RequestMapping("/inscriptions")
public class InscriptionController {

    private final InscriptionService inscriptionService;
    private final EtudiantService etudiantService;
    private final FormationService formationService;

    public InscriptionController(
            InscriptionService inscriptionService,
            EtudiantService etudiantService,
            FormationService formationService
    ) {
        this.inscriptionService = inscriptionService;
        this.etudiantService = etudiantService;
        this.formationService = formationService;
    }

    @GetMapping
    public String listInscriptions(Model model) {
        model.addAttribute("inscriptions", inscriptionService.getAllInscriptions());
        return "inscriptions/list";
    }

    @GetMapping("/new")
    public String showForm(Model model) {
        model.addAttribute("inscription", new Inscription());
        model.addAttribute("etudiants", etudiantService.getAllEtudiants());
        model.addAttribute("formations", formationService.getAllFormations());
        return "inscriptions/form";
    }

    @PostMapping
    public String saveInscription(@ModelAttribute Inscription inscription) {
        inscription.setDateInscription(LocalDate.now());
        inscriptionService.saveInscription(inscription);
        return "redirect:/inscriptions";
    }

    @GetMapping("/delete/{id}")
    public String deleteInscription(@PathVariable Long id) {
        inscriptionService.deleteInscription(id);
        return "redirect:/inscriptions";
    }
}
