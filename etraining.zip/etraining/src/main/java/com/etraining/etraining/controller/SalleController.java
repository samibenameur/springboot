package com.etraining.etraining.controller;

import com.etraining.etraining.entity.Salle;
import com.etraining.etraining.service.SalleService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/salles")
public class SalleController {

    private final SalleService salleService;

    public SalleController(SalleService salleService) {
        this.salleService = salleService;
    }

    @GetMapping
    public String listSalles(Model model) {
        model.addAttribute("salles", salleService.getAllSalles());
        return "salles/list";
    }

    @GetMapping("/new")
    public String showForm(Model model) {
        model.addAttribute("salle", new Salle());
        return "salles/form";
    }

    @PostMapping
    public String saveSalle(@ModelAttribute Salle salle) {
        salleService.saveSalle(salle);
        return "redirect:/salles";
    }

    @GetMapping("/edit/{id}")
    public String editSalle(@PathVariable Long id, Model model) {
        Salle salle = salleService.getSalleById(id).orElseThrow();
        model.addAttribute("salle", salle);
        return "salles/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteSalle(@PathVariable Long id) {
        salleService.deleteSalle(id);
        return "redirect:/salles";
    }
}
