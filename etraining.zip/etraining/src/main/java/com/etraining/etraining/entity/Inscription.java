package com.etraining.etraining.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Inscription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Etudiant etudiant;

    @ManyToOne
    private Formation formation;

    private LocalDate dateInscription;

    public Inscription() {}

    public Inscription(Etudiant etudiant, Formation formation, LocalDate dateInscription) {
        this.etudiant = etudiant;
        this.formation = formation;
        this.dateInscription = dateInscription;
    }

    // Getters / Setters
    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public Etudiant getEtudiant() { return etudiant; }

    public void setEtudiant(Etudiant etudiant) { this.etudiant = etudiant; }

    public Formation getFormation() { return formation; }

    public void setFormation(Formation formation) { this.formation = formation; }

    public LocalDate getDateInscription() { return dateInscription; }

    public void setDateInscription(LocalDate dateInscription) { this.dateInscription = dateInscription; }
}
