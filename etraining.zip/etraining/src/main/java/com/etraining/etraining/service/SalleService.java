package com.etraining.etraining.service;

import com.etraining.etraining.entity.Salle;
import com.etraining.etraining.repository.SalleRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SalleService {

    private final SalleRepository salleRepository;

    public SalleService(SalleRepository salleRepository) {
        this.salleRepository = salleRepository;
    }

    public List<Salle> getAllSalles() {
        return salleRepository.findAll();
    }

    public void saveSalle(Salle salle) {
        salleRepository.save(salle);
    }

    public Optional<Salle> getSalleById(Long id) {
        return salleRepository.findById(id);
    }

    public void deleteSalle(Long id) {
        salleRepository.deleteById(id);
    }
}
