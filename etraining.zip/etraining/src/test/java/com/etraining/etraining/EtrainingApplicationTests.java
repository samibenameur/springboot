package com.etraining.etraining;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EtrainingApplicationTests {

	@Test
	void contextLoads() {
	}

}
